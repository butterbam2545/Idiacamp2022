public class Database
{
    public CollegeStudent[] CollegeStudents;
    public int CollegeStudentCount;
    public Professor[] Professors;
    public int ProfessorCount;
    public HighSchoolStudent[] HighSchoolStudents; 
    public int HighSchoolStudentCount;

    public Database()
    {
        CollegeStudents = new CollegeStudent[256];
        CollegeStudentCount = 0;
        Professors = new Professor[256];
        ProfessorCount = 0;
        HighSchoolStudents = new HighSchoolStudent[256];
        HighSchoolStudentCount = 0;
    }

    public void AddCollegeStudent(CollegeStudent collegeStudent)
    {
        CollegeStudents[CollegeStudentCount] = collegeStudent;
        CollegeStudentCount++;
    }

    public void AddHighSchoolStudent(HighSchoolStudent schoolStudent)
    {
        HighSchoolStudents[HighSchoolStudentCount] = schoolStudent;
        HighSchoolStudentCount++;
    }


    public void AddProfessor(Professor professor)
    {
        Professors[ProfessorCount] = professor;
        ProfessorCount++;
    }

    public bool ContainsPerson(Person person)
    {
        for (int i = 0; i < CollegeStudentCount; i++)
        {
            if (CollegeStudents[i].Equals(person))
            {
                return true;
            }
        }

        for (int i = 0; i < ProfessorCount; i++)
        {
            if (Professors[i].Equals(person))
            {
                return true;
            }
        }

        for (int i = 0; i < HighSchoolStudentCount; i++)
        {
            if (HighSchoolStudents[i].Equals(person))
            {
                return true;
            }
        }

        return false;
    }

    public bool ContainsEmail(string email)
    {
        // Check if email is in college students and professors
        for (int i = 0; i < CollegeStudentCount; i++)
        {
            if (CollegeStudents[i].Email == email)
            {
                return true;
            }
        }

        for (int i = 0; i < ProfessorCount; i++)
        {
            if (Professors[i].Email == email)
            {
                return true;
            }
        }

        return false;
    }

    public Person Authenticate(string email, string password)
    {
        for (int i = 0; i < CollegeStudentCount; i++)
        {
            if (CollegeStudents[i].Email == email && CollegeStudents[i].Password == password)
            {
                return CollegeStudents[i];
            }
        }

        for (int i = 0; i < ProfessorCount; i++)
        {
            if (Professors[i].Email == email && Professors[i].Password == password)
            {
                return Professors[i];
            }
        }

        return null;
    }
}
