public class Person
{
    public string Title { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public int Age { get; set; }
    public string Allergies { get; set; }
    public string Religion { get; set; }


    public Person(string title, 
    string firstName, 
    string lastName, 
    int age, 
    string allergies, 
    string religion)
    {
        Title = title;
        FirstName = firstName;
        LastName = lastName;
        Age = age;
        Allergies = allergies;
        Religion = religion;
    }

    public bool Equals(Person person)
    {
        return Title == person.Title && FirstName == person.FirstName && LastName == person.LastName;
    }

    public void Print()
    {
        Console.WriteLine("Title: " + Title);
        Console.WriteLine("First Name: " + FirstName);
        Console.WriteLine("Last Name: " + LastName);
        Console.WriteLine("Age: " + Age);
        Console.WriteLine("Allergies: " + Allergies);
        Console.WriteLine("Religion: " + Religion);
    }
}
