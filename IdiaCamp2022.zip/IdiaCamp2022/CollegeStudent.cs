
public class CollegeStudent : Person
{
    public string Id { get; set; }
    public bool IsAdmin { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }

    public CollegeStudent(string title, 
    string firstName, 
    string lastName, 
    int age, 
    string allergies, 
    string religion, 
    string id, 
    bool isAdmin, 
    string email, 
    string password) 
    : base(title, 
    firstName, 
    lastName, 
    age, 
    allergies, 
    religion)
    {
        Id = id;
        IsAdmin = isAdmin;
        Email = email;
        Password = password;
    }

    public CollegeStudent(Person person, 
    string id, 
    bool isAdmin, 
    string email, 
    string password) 
    : base(person.Title, 
    person.FirstName, 
    person.LastName, 
    person.Age, 
    person.Allergies,
     person.Religion)
    {
        Id = id;
        IsAdmin = isAdmin;
        Email = email;
        Password = password;
    }

    public void Print()
    {
        Console.WriteLine("Title: " + Title);
        Console.WriteLine("First name: " + FirstName);
        Console.WriteLine("Last name: " + LastName);
        Console.WriteLine("Age: " + Age);
        Console.WriteLine("Allergies: " + Allergies);
        Console.WriteLine("Religion: " + Religion);
        Console.WriteLine("Id: " + Id);
        Console.WriteLine("Is admin: " + IsAdmin);
        Console.WriteLine("email: " + Email);
    }
}
