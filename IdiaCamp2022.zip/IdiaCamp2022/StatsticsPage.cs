public class StatisticsPage
{
    private App app;

    public StatisticsPage(App app)
    {
        this.app = app;
    }

    public App.Page Do()
    {
        Console.Clear();
        Console.WriteLine("IdiaCamp2022 Registration Statistics");
        Console.WriteLine("\nNumber of registered college students: " + app.Database.CollegeStudentCount);

        Console.WriteLine("\nNumber of registered high school students: " + app.Database.HighSchoolStudentCount);
        Console.WriteLine("Students in matthayom 4: " + GetTotalHighSchoolStudents(HighSchoolStudent.GradeEnum.Matthayom4));
        Console.WriteLine("Students in matthayom 5: " + GetTotalHighSchoolStudents(HighSchoolStudent.GradeEnum.Matthayom5));
        Console.WriteLine("Students in matthayom 6: " + GetTotalHighSchoolStudents(HighSchoolStudent.GradeEnum.Matthayom6));

        Console.WriteLine("\nNumber of registered professors: " + app.Database.ProfessorCount);

        Console.WriteLine("\nPress any key to return to the main menu...");
        Console.ReadKey();
        return App.Page.MainMenu;
    }

    public int GetTotalHighSchoolStudents(HighSchoolStudent.GradeEnum grade)
    {
        int count = 0;
        for (int i = 0; i < app.Database.HighSchoolStudentCount; i++)
        {
            if (app.Database.HighSchoolStudents[i].Grade == grade)
            {
                count++;
            }
        }
        return count;
    }
}
