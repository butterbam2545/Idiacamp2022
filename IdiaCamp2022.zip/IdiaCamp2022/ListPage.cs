public class ListPage
{
    private App app;

    public enum Field
    {
        CollegeStudents,
        HighSchoolStudents,
        Professors,
    }

    public ListPage(App app)
    {
        this.app = app;
    }

    public App.Page Do(Field field)
    {
        Console.Clear();
        Console.Write("List of registered ");
        switch (field)
        {
            case Field.CollegeStudents:
                Console.WriteLine("college students");
                break;
            case Field.HighSchoolStudents:
                Console.WriteLine("high school students");
                break;
            case Field.Professors:
                Console.WriteLine("professors");
                break;
        }

        Console.WriteLine("\n \tTitle\t\tFirst name\tLast name\n");


        switch (field)
        {
            case Field.CollegeStudents:
                if (app.Database.CollegeStudentCount == 0)
                {
                    Console.WriteLine("No college students registered");
                }
                else
                {
                    for (int i = 0; i < app.Database.CollegeStudentCount; i++)
                    {
                        CollegeStudent participant = app.Database.CollegeStudents[i];
                        Console.WriteLine(i + "\t" + participant.Title + "\t\t" + participant.FirstName + "\t\t" + participant.LastName);
                    }
                }
                break;
            case Field.HighSchoolStudents:
                if (app.Database.HighSchoolStudentCount == 0)
                {
                    Console.WriteLine("No high school students registered yet.");
                }
                else
                {
                    for (int i = 0; i < app.Database.HighSchoolStudentCount; i++)
                    {
                        HighSchoolStudent participant = app.Database.HighSchoolStudents[i];
                        Console.WriteLine(i + "\t" + participant.Title + "\t\t" + participant.FirstName + "\t" + participant.LastName);
                    }
                }
                break;
            case Field.Professors:
                if (app.Database.ProfessorCount == 0)
                {
                    Console.WriteLine("No professors registered yet.");
                }
                else
                {
                    for (int i = 0; i < app.Database.ProfessorCount; i++)
                    {
                        Professor participant = app.Database.Professors[i];
                        Console.WriteLine(i + "\t" + participant.Title + "\t\t" + participant.FirstName + "\t" + participant.LastName);
                    }
                }
                break;
        }
        Console.WriteLine("\nPress any key to return to the main menu...");
        Console.ReadKey();
        return App.Page.MainMenu;
    }

}
