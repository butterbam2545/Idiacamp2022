public class LoginPage
{
    private App app;
    public LoginPage(App app)
    {
        this.app = app;
    }

    public App.Page Do()
    {
        Console.Clear();
        Console.WriteLine("Please enter your email and password to login as admin:");
        Console.Write("\nEmail: ");
        string email = Console.ReadLine() ?? "";
        if (email.ToLower() == "exit")
        {
            return App.Page.MainMenu;
        }
        Console.Write("\nPassword: ");
        string password = Console.ReadLine() ?? "";

        if (email == "" || password == "")
        {
            Console.WriteLine("\nEmail and password cannot be empty!");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            return App.Page.Login;
        }

        Person user = app.Database.Authenticate(email, password);
        if (user == null)
        {
            Console.WriteLine("\nIncorrect email or password. Please try again.");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            return App.Page.Login;
        }

        app.LoggedIn = true;
        app.CurrentUser = user;
        Console.WriteLine("\nLogin successful!");
        Console.WriteLine("Press any key to continue...");
        Console.ReadKey();
        return App.Page.MainMenu;
    }

}
