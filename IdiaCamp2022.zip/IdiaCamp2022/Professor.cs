public class Professor : Person
{
    public string Position { get; set; }
    public bool WithCar { get; set; }
    public string CarNumber { get; set; }
    public bool IsAdmin { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }

    public static Professor[] Professors = new Professor[256];

    public Professor(string title, 
    string firstName, 
    string lastName,
    int age, 
    string allergies, 
    string religion, 
    string position, 
    bool withCar, 
    string carNumber, 
    bool isAdmin, 
    string email, 
    string password) 
    : base(title, firstName, lastName, age, allergies, religion)
    {
        Position = position;
        WithCar = withCar;
        CarNumber = carNumber;
        IsAdmin = isAdmin;
        Email = email;
        Password = password;
    }

    public Professor(Person person, 
    string position, 
    bool withCar, 
    string carNumber, 
    bool isAdmin, 
    string email, 
    string password) 
    : base(person.Title, person.FirstName, person.LastName, person.Age, person.Allergies, person.Religion)
    {
        Position = position;
        WithCar = withCar;
        CarNumber = carNumber;
        IsAdmin = isAdmin;
        Email = email;
        Password = password;
    }

    public void Print()
    {
        Console.WriteLine("Title: " + Title);
        Console.WriteLine("First name: " + FirstName);
        Console.WriteLine("Last name: " + LastName);
        Console.WriteLine("Age: " + Age);
        Console.WriteLine("Allergies: " + Allergies);
        Console.WriteLine("Religion: " + Religion);
        Console.WriteLine("Position: " + Position);
        Console.WriteLine("With car: " + WithCar);
        Console.WriteLine("Car number: " + CarNumber);
        Console.WriteLine("Is admin: " + IsAdmin);
        Console.WriteLine("Admin email: " + Email);
    }
}
