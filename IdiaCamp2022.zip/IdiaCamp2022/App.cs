
public class App
{
    public enum Page
    {
        MainMenu,
        Register,
        Login,
        Statistics,
        ListCollegeStudents,
        ListHighSchoolStudents,
        ListProfessors,
    }

    public Database Database { get; set; }
    public bool LoggedIn { get; set; }
    public Person CurrentUser { get; set; }
    public Page CurrentPage { get; set; }

    public App()
    {
        Database = new Database();
        LoggedIn = false;
        CurrentUser = null;
        CurrentPage = Page.MainMenu;
    }

    public void Run()
    {
        Console.Clear();
        while (true)
        {
            switch (CurrentPage)
            {
                case Page.MainMenu:
                    CurrentPage = DoMainMenu();
                    break;
                case Page.Register:
                    CurrentPage = new RegisterPage(this).Do();
                    break;
                case Page.Login:
                    CurrentPage = new LoginPage(this).Do();
                    break;
                case Page.Statistics:
                    CurrentPage = new StatisticsPage(this).Do();
                    break;
                case Page.ListCollegeStudents:
                    CurrentPage = new ListPage(this).Do(ListPage.Field.CollegeStudents);
                    break;
                case Page.ListHighSchoolStudents:
                    CurrentPage = new ListPage(this).Do(ListPage.Field.HighSchoolStudents);
                    break;
                case Page.ListProfessors:
                    CurrentPage = new ListPage(this).Do(ListPage.Field.Professors);
                    break;
            }
        }
    }

    public void ShowMainMenu()
    {
        Console.Clear();
        Console.WriteLine("IdiaCamp2022 Registration System");
        if (LoggedIn)
        {
            Console.WriteLine("Hello " + CurrentUser.FirstName + "!");
        }
        Console.WriteLine("\nPlease select an option:");
        Console.WriteLine("1. Register for IdiaCamp2022");

        if (LoggedIn)
        {
            Console.WriteLine("2. List all registered college students");
            Console.WriteLine("3. List all registered high school students");
            Console.WriteLine("4. List all registered professors");
            Console.WriteLine("5. Logout");
        }
        else
        {
            Console.WriteLine("2. Show registration statistics");
            Console.WriteLine("3. Login as admin");
        }

        Console.Write("Option: ");
    }

    private App.Page DoMainMenu()
    {
        while (true)
        {
            ShowMainMenu();
            string option = Console.ReadLine() ?? "";

            if (option == "")
            {
                continue;
            }

            if (LoggedIn)
            {
                switch (option)
                {
                    case "1":
                        return App.Page.Register;
                    case "2":
                        return App.Page.ListCollegeStudents;
                    case "3":
                        return App.Page.ListHighSchoolStudents;
                    case "4":
                        return App.Page.ListProfessors;
                    case "5":
                        LoggedIn = false;
                        CurrentUser = null;
                        return App.Page.MainMenu;
                }
            }
            else
            {
                switch (option)
                {
                    case "1":
                        return App.Page.Register;
                    case "2":
                        return App.Page.Statistics;
                    case "3":
                        return App.Page.Login;
                }
            }
        }
        Console.WriteLine("Invalid option");
        return App.Page.MainMenu;
    }
}
