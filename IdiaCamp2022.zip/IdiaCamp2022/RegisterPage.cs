public class RegisterPage
{

    private App App;

    public RegisterPage(App app)
    {
        App = app;
    }

    public App.Page Do()
    {
        Console.Clear();
        string option = "";
        while (true)
        {
            Console.WriteLine("Please select an option:");
            Console.WriteLine("1. Register as a college student");
            Console.WriteLine("2. Register as a high school student");
            Console.WriteLine("3. Register as a professor");
            Console.Write("Option (1,2,3): ");
            option = Console.ReadLine() ?? "";
            if (option != "1" && option != "2" && option != "3")
            {
                Console.WriteLine("Invalid option, please input 1, 2 or 3");
                continue;
            }

            break;
        }

        Person person = CreatePerson();

        if (person == null)
        {
            return App.Page.Register;
        }

        switch (option)
        {
            case "1":
                person = CreateCollegeStudent(person);
                break;
            case "2":
                person = CreateHighSchoolStudent(person);
                break;
            case "3":
                person = CreateProfessor(person);
                break;
        }

        if (person == null)
        {
            return App.Page.Register;
        }

        person.Print();

        Console.Write("\nDo you confirm the registration? (Y/N): ");
        string confirm = Console.ReadLine() ?? "";
        if (confirm == "N" || confirm == "n")
        {
            Console.WriteLine("\nRegistration cancelled!");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            return App.Page.Register;
        }

        switch (option)
        {
            case "1":
                App.Database.AddCollegeStudent((CollegeStudent)person);
                break;
            case "2":
                App.Database.AddHighSchoolStudent((HighSchoolStudent)person);
                break;
            case "3":
                App.Database.AddProfessor((Professor)person);
                break;
        }

        Console.WriteLine("\nSuccessfully registered!");
        Console.WriteLine("Press any key to continue...");
        Console.ReadKey();

        return App.Page.MainMenu;
    }

    public Person CreatePerson()
    {
        Console.WriteLine("\nPlease select a title:");
        Console.WriteLine("1. Mister (Mr.)");
        Console.WriteLine("2. Misses (Mrs.)");
        Console.WriteLine("3. Miss (Ms.)");
        string title = "";
        while (true)
        {
            Console.Write("INPUT (1,2,3): ");
            title = Console.ReadLine() ?? "";

            switch (title)
            {
                case "1":
                    title = "Mister";
                    break;
                case "2":
                    title = "Misses";
                    break;
                case "3":
                    title = "Miss";
                    break;
                default:
                    Console.WriteLine("Invalid option, please input 1, 2 or 3");
                    continue;
            }

            break;
        }

        string firstName = "";
        while (firstName == "")
        {
            Console.Write("\nPlease input your first name: ");
            firstName = Console.ReadLine() ?? "";
        }

        string lastName = "";
        while (lastName == "")
        {
            Console.Write("Please input your last name: ");
            lastName = Console.ReadLine() ?? "";
        }

        if (App.Database.ContainsPerson(new Person(title, firstName, lastName, 0, "", "")))
        {
            Console.WriteLine("\nUser is already registered. Please try again.");
            Console.Write("Press any key to continue...");
            Console.ReadKey();
            return null;
        }

        int age = 0;
        while (age == 0)
        {
            Console.Write("\nPlease input your age: ");
            string ageString = Console.ReadLine() ?? "";
            if (!int.TryParse(ageString, out age))
            {
                Console.WriteLine("Invalid age, please input an integer value");
                continue;
            }

            if (age < 0)
            {
                Console.WriteLine("Invalid age, please input a positive number");
                continue;
            }

            break;
        }

        string allergies = "";
        while (allergies != "Y" && allergies != "N" && allergies != "y" && allergies != "n")
        {
            Console.Write("\nDo you have any allergies? (Y/N): ");
            allergies = Console.ReadLine() ?? "";
            if (allergies != "Y" && allergies != "N" && allergies != "y" && allergies != "n")
            {
                Console.WriteLine("Invalid option, please input Y or N");
                continue;
            }

            break;
        }

        if (allergies == "Y" || allergies == "y")
        {
            Console.WriteLine("\nPlease input your allergies (comma separated) e.g. peanuts, shellfish");
            Console.Write("Allergies: ");
            allergies = Console.ReadLine() ?? "";
        }
        else
        {
            allergies = "";
        }

        string religion = "";
        while (true)
        {
            Console.WriteLine("\nPlease select a religion:");
            Console.WriteLine("1. Buddhist");
            Console.WriteLine("2. Christian");
            Console.WriteLine("3. Islam");
            Console.WriteLine("4. Other");
            Console.Write("INPUT (1,2,3,4): ");
            religion = Console.ReadLine() ?? "";

            switch (religion)
            {
                case "1":
                    religion = "Buddhist";
                    break;
                case "2":
                    religion = "Christian";
                    break;
                case "3":
                    religion = "Islam";
                    break;
                case "4":
                    religion = "Other";
                    break;
                default:
                    Console.WriteLine("Invalid option, please input 1, 2, 3 or 4");
                    continue;
            }

            break;
        }

        return new Person(title, firstName, lastName, age, allergies, religion);
    }

    public CollegeStudent CreateCollegeStudent(Person person)
    {
        string id = "";
        while (id == "")
        {
            Console.Write("\nPlease input your student ID: ");
            id = Console.ReadLine() ?? "";
        }

        bool isAdmin;
        while (true)
        {
            Console.Write("\nAre you an admin? (Y/N): ");
            string isAdminInput = Console.ReadLine() ?? "";
            if (isAdminInput == "Y" || isAdminInput == "y")
            {
                isAdmin = true;
                break;
            }

            if (isAdminInput == "N" || isAdminInput == "n")
            {
                isAdmin = false;
                break;
            }

            Console.WriteLine("Invalid option, please input Y or N");
        }

        if (!isAdmin)
        {
            return new CollegeStudent(person, id, isAdmin, "", "");
        }

        string email = "";
        while (email == "")
        {
            Console.Write("\nPlease input your admin email: ");
            email = Console.ReadLine() ?? "";
        }

        if (email.ToLower() == "exit" || App.Database.ContainsEmail(email))
        {
            Console.WriteLine("Invalid email. Please try again.");
            Console.Write("Press any key to continue...");
            Console.ReadKey();
            return null;
        }

        string password = "";
        while (password == "")
        {
            Console.Write("Please input your admin password: ");
            password = Console.ReadLine() ?? "";
        }

        return new CollegeStudent(person, id, isAdmin, email, password);
    }

    public HighSchoolStudent CreateHighSchoolStudent(Person person)
    {
        Console.WriteLine("\nPlease select a grade:");
        Console.WriteLine("1. Matthayom 4");
        Console.WriteLine("2. Matthayom 5");
        Console.WriteLine("3. Matthayom 6");
        String gradeInput = "";
        HighSchoolStudent.GradeEnum grade = HighSchoolStudent.GradeEnum.Matthayom4;
        while (gradeInput == "")
        {
            Console.Write("Please  (1,2,3): ");
            gradeInput = Console.ReadLine() ?? "";

            switch (gradeInput)
            {
                case "1":
                    grade = HighSchoolStudent.GradeEnum.Matthayom4;
                    break;
                case "2":
                    grade = HighSchoolStudent.GradeEnum.Matthayom5;
                    break;
                case "3":
                    grade = HighSchoolStudent.GradeEnum.Matthayom6;
                    break;
                default:
                    Console.WriteLine("Invalid option, please input 1, 2 or 3");
                    continue;
            }
        }

        string school = "";
        while (school == "")
        {
            Console.Write("\nPlease input your school: ");
            school = Console.ReadLine() ?? "";
        }

        return new HighSchoolStudent(person, school, grade);
    }

    public Professor CreateProfessor(Person person)
    {
        string position = "";
        Console.WriteLine("\nPlease select your position:");
        Console.WriteLine("1. Dean");
        Console.WriteLine("2. Head of Department");
        Console.WriteLine("3. Lecturer");
        while (position == "")
        {
            Console.Write("INPUT (1,2,3): ");
            position = Console.ReadLine() ?? "";
        }

        bool withCar;
        while (true)
        {
            Console.Write("\nWill you bring your car to the event? (Y/N): ");
            string withCarString = Console.ReadLine() ?? "";
            if (withCarString == "Y" || withCarString == "y")
            {
                withCar = true;
                break;
            }

            if (withCarString == "N" || withCarString == "n")
            {
                withCar = false;
                break;
            }

            Console.WriteLine("Invalid option, please input Y or N");
        }

        string carNumber = "";
        if (withCar)
        {
            while (carNumber == "")
            {
                Console.Write("\nPlease input your car number: ");
                carNumber = Console.ReadLine() ?? "";
            }
        }

        bool isAdmin;
        while (true)
        {
            Console.Write("\nAre you an admin? (Y/N): ");
            string isAdminInput = Console.ReadLine() ?? "";
            if (isAdminInput == "Y" || isAdminInput == "y")
            {
                isAdmin = true;
                break;
            }

            if (isAdminInput == "N" || isAdminInput == "n")
            {
                isAdmin = false;
                break;
            }

            Console.WriteLine("Invalid option, please input Y or N");
        }

        if (!isAdmin)
        {
            return new Professor(person, position, withCar, carNumber, isAdmin, "", "");
        }

        string email = "";
        while (email == "")
        {
            Console.Write("\nPlease input your admin email: ");
            email = Console.ReadLine() ?? "";
        }

        if (App.Database.ContainsEmail(email))
        {
            Console.WriteLine("Invalid email. Please try again.");
            Console.Write("Press any key to continue...");
            Console.ReadKey();
            return null;
        }

        string password = "";
        while (password == "")
        {
            Console.Write("Please input your admin password: ");
            password = Console.ReadLine() ?? "";
        }

        return new Professor(person, position, withCar, carNumber, isAdmin, email, password);
    }
}
