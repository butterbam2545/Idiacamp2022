public class HighSchoolStudent : Person
{
    public enum GradeEnum
    {
        Matthayom4,
        Matthayom5,
        Matthayom6
    }
    public string School { get; set; }
    public GradeEnum Grade { get; set; }

    public HighSchoolStudent(string title, 
    string firstName, 
    string lastName, 
    int age, 
    string allergies, 
    string religion, 
    string school, 
    GradeEnum grade) 
    : base(title, 
    firstName, 
    lastName, 
    age, 
    allergies, 
    religion)
    {
        School = school;
        Grade = grade;
    }

    public HighSchoolStudent(Person person, 
    string school, 
    GradeEnum grade) 
    : base(person.Title, 
    person.FirstName, 
    person.LastName, 
    person.Age, 
    person.Allergies, 
    person.Religion)
    {
        School = school;
        Grade = grade;
    }

    public void Print()
    {
        Console.WriteLine("Title: " + Title);
        Console.WriteLine("First name: " + FirstName);
        Console.WriteLine("Last name: " + LastName);
        Console.WriteLine("Age: " + Age);
        Console.WriteLine("Allergies: " + Allergies);
        Console.WriteLine("Religion: " + Religion);
        Console.WriteLine("School: " + School);
        Console.WriteLine("Grade: " + Grade);
    }
}
